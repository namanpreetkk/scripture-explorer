"""Optional: build every cache (classifier, embeddings, UMAP) before opening the app.

    python scripts/prebuild.py            # 8000 verses per scripture
    python scripts/prebuild.py 0          # all verses (slow on CPU)
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from scripture_explorer import classifier, data, mapping
from scripture_explorer.search import SearchIndex

max_per = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
df = data.load_corpus()
print(f"{len(df):,} verses loaded")
classifier.load_or_train(df)
print("classifier ready")
index = SearchIndex.load_or_build(df, max_per or None, progress=lambda p: print(f"\rembedding {p:.0%}", end=""))
mapping.umap_xy(index.emb, f"n{max_per or 'all'}")
print("\nall caches built")
