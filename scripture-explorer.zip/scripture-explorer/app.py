"""Scripture Explorer: Streamlit app.  Run with:  streamlit run app.py"""
import pandas as pd
import plotly.express as px
import streamlit as st

from scripture_explorer import classifier, data, mapping
from scripture_explorer.search import SearchIndex

st.set_page_config(page_title="Scripture Explorer", page_icon="📜", layout="wide")


# ---------- cached loaders ----------
@st.cache_data(show_spinner="Loading corpus (first run downloads the dataset)…")
def get_corpus() -> pd.DataFrame:
    return data.load_corpus()


@st.cache_resource(show_spinner="Training classifier (first run only)…")
def get_classifier(_df):
    return classifier.load_or_train(_df)


@st.cache_resource(show_spinner=False)
def get_index(_df, max_per: int) -> SearchIndex:
    bar = st.progress(0.0, text="Embedding verses (first run only, a few minutes)…")
    index = SearchIndex.load_or_build(_df, max_per or None, progress=lambda p: bar.progress(p))
    bar.empty()
    return index


@st.cache_data(show_spinner="Running UMAP (first run only)…")
def get_map(max_per: int) -> pd.DataFrame:
    index = get_index(df, max_per)
    xy = mapping.umap_xy(index.emb, f"n{max_per or 'all'}")
    return mapping.plot_frame(index.idx, xy)


# ---------- load data ----------
try:
    df = get_corpus()
except RuntimeError as e:
    st.error(str(e))
    st.stop()

SCRIPTURES = sorted(df.scripture.unique())

# ---------- sidebar ----------
st.sidebar.title("📜 Scripture Explorer")
st.sidebar.caption("Data: DharmicData (Sanskrit, verse level)")
max_per = st.sidebar.number_input(
    "Verses to index per scripture (0 = all)", min_value=0, max_value=60000, value=8000, step=1000,
    help="Lower = faster embedding. Changing this builds a new index the first time.")
st.sidebar.metric("Total verses", f"{len(df):,}")

st.title("📜 Scripture Explorer")
st.write("Classify a verse, search by meaning, or explore a 2D map of the Mahabharata, "
         "Ramayana, Rigveda and Yajurveda.")

tab_cls, tab_search, tab_map, tab_data = st.tabs(
    ["🔎 Which scripture?", "🧠 Semantic search", "🗺️ 2D map", "📊 Dataset & metrics"])

# ---------- Tab 1: classifier ----------
with tab_cls:
    bundle = get_classifier(df)
    verse = st.text_area("Paste a Sanskrit verse (Devanagari)", height=110,
                         placeholder="अग्निमीळे पुरोहितं यज्ञस्य देवमृत्विजम्")
    if st.button("Predict", type="primary") and verse.strip():
        probs = classifier.predict_scripture(bundle["clf"], verse)
        top = max(probs, key=probs.get)
        st.success(f"Most likely: **{top}** ({probs[top]:.1%})")
        st.plotly_chart(
            px.bar(x=list(probs.values()), y=list(probs.keys()), orientation="h",
                   labels={"x": "probability", "y": ""}, range_x=[0, 1]).update_layout(height=260),
            width="stretch")

# ---------- Tab 2: semantic search ----------
with tab_search:
    st.caption("Hindi/Sanskrit (Devanagari) queries work best. English works partly, mainly for the Ramayana.")
    q = st.text_input("Query", placeholder="धर्म का पालन करना चाहिए")
    c1, c2 = st.columns(2)
    scr = c1.selectbox("Restrict to", ["All"] + SCRIPTURES)
    k = c2.slider("Number of results", 1, 10, 5)
    if st.button("Search", type="primary") and q.strip():
        index = get_index(df, max_per)
        st.dataframe(index.search(q, k, scr), width="stretch", hide_index=True)

# ---------- Tab 3: UMAP map ----------
with tab_map:
    st.caption("Each dot is a verse. Points close together are semantically similar. Hover for details.")
    if st.button("Build / show map", type="primary"):
        st.session_state["show_map"] = True
    if st.session_state.get("show_map"):
        pf = get_map(max_per)
        fig = px.scatter(pf, x="x", y="y", color="scripture", hover_data=["ref", "verse"],
                         opacity=0.6, render_mode="webgl", height=650)
        fig.update_traces(marker=dict(size=4))
        fig.update_layout(xaxis_title="", yaxis_title="", xaxis_showticklabels=False,
                          yaxis_showticklabels=False)
        st.plotly_chart(fig, width="stretch")
        st.subheader("Similarity between scriptures (centroids)")
        st.plotly_chart(px.imshow(get_index(df, max_per).centroid_similarity(), text_auto=True,
                                  color_continuous_scale="Blues"), width="stretch")

# ---------- Tab 4: dataset & metrics ----------
with tab_data:
    counts = df.scripture.value_counts()
    st.plotly_chart(px.bar(counts, labels={"value": "verses", "scripture": ""}, title="Verses per scripture"),
                    width="stretch")
    st.dataframe(df.groupby("scripture").head(1)[["scripture", "ref", "text"]], hide_index=True,
                 width="stretch")
    b = get_classifier(df)
    st.subheader("Classifier results (20% held-out test set)")
    st.dataframe(b["scores"], width="stretch")
    st.dataframe(b["report"], width="stretch")
    st.plotly_chart(px.imshow(b["cm"], text_auto=True, color_continuous_scale="Blues",
                              title="Confusion matrix (row-normalised)"), width="stretch")
    st.info("Accuracy is very high partly because the corpora differ in style and spelling "
            "(e.g. Mahabharata transliteration, archaic Vedic vocabulary), not only meaning. "
            "Rigveda vs Yajurveda is the hardest pair.")
