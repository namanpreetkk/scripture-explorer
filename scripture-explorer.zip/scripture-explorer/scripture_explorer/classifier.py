"""Part 1: which scripture is this verse from? TF-IDF char n-grams + SVM / LogReg."""
import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.svm import LinearSVC

from .config import ARTIFACTS, SEED
from .data import clean

CACHE = ARTIFACTS / "classifier.joblib"


def _make(model):
    return make_pipeline(
        TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 4), max_features=150_000, sublinear_tf=True),
        model,
    )


def train(df: pd.DataFrame) -> dict:
    tr, te = train_test_split(df, test_size=0.2, stratify=df.scripture, random_state=SEED)
    models = {
        "Linear SVM": _make(LinearSVC(class_weight="balanced")),
        "Logistic Regression": _make(LogisticRegression(max_iter=300, class_weight="balanced")),
    }
    scores = {}
    for name, clf in models.items():
        clf.fit(tr.text, tr.scripture)
        p = clf.predict(te.text)
        scores[name] = {"accuracy": accuracy_score(te.scripture, p),
                        "macro-F1": f1_score(te.scripture, p, average="macro")}

    clf = models["Logistic Regression"]  # gives probabilities for the demo
    pred = clf.predict(te.text)
    labels = list(clf.classes_)
    return dict(
        clf=clf,
        scores=pd.DataFrame(scores).T.round(4),
        report=pd.DataFrame(classification_report(te.scripture, pred, output_dict=True, digits=3)).T.round(3),
        cm=pd.DataFrame(confusion_matrix(te.scripture, pred, labels=labels, normalize="true"),
                        index=labels, columns=labels).round(3),
    )


def load_or_train(df: pd.DataFrame) -> dict:
    if CACHE.exists():
        return joblib.load(CACHE)
    bundle = train(df)
    joblib.dump(bundle, CACHE)
    return bundle


def predict_scripture(clf, verse: str) -> dict:
    probs = clf.predict_proba([clean(verse)])[0]
    return {c: float(p) for c, p in zip(clf.classes_, probs)}
