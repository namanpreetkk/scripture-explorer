"""Load the DharmicData JSON files and convert them into one table of verses.

Columns: scripture | ref | raw | translation | text
`text` is the cleaned version used by the models.
"""
import glob
import json
import re
import subprocess
import unicodedata

import pandas as pd

from .config import DATA_DIR, REPO_URL

D2A = str.maketrans("०१२३४५६७८९", "0123456789")  # Devanagari -> ASCII digits
MARK = re.compile(r"॥\s*[०-९]+\s*॥")
YM = re.compile(r"(?:॥|।।)\s*[०-९0-9]+\s*(?:॥|।।)+")
ACCENTS = re.compile(r"[\u0951-\u0954\u1CD0-\u1CFF\uA8E0-\uA8FF\u1CEA\u00AC]")


def ensure_data() -> None:
    """Clone the dataset the first time the app runs."""
    if DATA_DIR.exists():
        return
    DATA_DIR.parent.mkdir(parents=True, exist_ok=True)
    try:
        subprocess.run(
            ["git", "clone", "-q", "--depth", "1", REPO_URL, str(DATA_DIR)],
            check=True,
        )
    except (FileNotFoundError, subprocess.CalledProcessError) as e:
        raise RuntimeError(
            "Could not download the dataset. Install git, or run manually:\n"
            f"  git clone --depth 1 {REPO_URL} data/DharmicData"
        ) from e


def _load(path: str):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def clean(t: str) -> str:
    """Remove verse numbers, danda marks and Vedic accents so models can't 'cheat'."""
    t = unicodedata.normalize("NFC", t)
    t = ACCENTS.sub("", t)
    t = re.sub(r"\[[^\]]*\]", " ", t)                  # speaker tags like [सूत]
    t = re.sub(r"[0-9०-९]+", " ", t)                   # verse numbers
    t = re.sub(r"[।॥|,.;:!?\-–—'\"()\[\]]+", " ", t)   # punctuation / danda
    return re.sub(r"\s+", " ", t).strip()


def load_corpus() -> pd.DataFrame:
    ensure_data()
    root = str(DATA_DIR)
    rows = []

    # Mahabharata: one record per shloka
    for f in sorted(glob.glob(f"{root}/Mahabharata/mahabharata_book_*.json")):
        for r in _load(f):
            rows.append(dict(scripture="Mahabharata",
                             ref=f"Book {r['book']}.{r['chapter']}.{r['shloka']}",
                             raw=r["text"], translation=None))

    # Valmiki Ramayana: one record per shloka (has English translation)
    for f in sorted(glob.glob(f"{root}/ValmikiRamayana/*.json")):
        for r in _load(f):
            rows.append(dict(scripture="Ramayana",
                             ref=f"{r['kaanda'].title()} {r['sarg']}.{r['shloka']}",
                             raw=r["text"], translation=r.get("translation")))

    # Rigveda: one record per sukta -> split into verses (each ends with ॥N॥)
    for f in sorted(glob.glob(f"{root}/Rigveda/*.json")):
        for r in _load(f):
            for ch in [c.strip() for c in re.split(r"\n\s*\n", r["text"]) if c.strip()]:
                m = MARK.search(ch)
                if m:  # chunks without a verse number are the sukta header
                    v = re.sub(r"[^०-९]", "", m.group(0)).translate(D2A)
                    rows.append(dict(scripture="Rigveda",
                                     ref=f"Mandala {r['mandala']} Sukta {r['sukta']} v{v}",
                                     raw=ch, translation=None))

    # Yajurveda: one record per adhyaya -> split on verse-number markers
    for f in sorted(glob.glob(f"{root}/Yajurveda/*.json")):
        for r in _load(f):
            adh = r.get("adhyaya", r.get("chapter"))
            name = "Madhyandina" if "madhyandina" in r.get("samhita", "") else "Kanva"
            for j, p in enumerate(YM.split(r["text"])):
                if p.strip():
                    rows.append(dict(scripture="Yajurveda",
                                     ref=f"{name} Adhyaya {adh} v{j+1}",
                                     raw=p.strip(), translation=None))

    df = pd.DataFrame(rows)
    df["text"] = df.raw.map(clean)
    df = df[df.text.str.len() >= 15].drop_duplicates("text").reset_index(drop=True)
    return df
