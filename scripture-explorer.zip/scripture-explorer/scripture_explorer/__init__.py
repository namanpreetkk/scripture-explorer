"""Scripture Explorer: classifier + semantic search + 2D map on the DharmicData corpus."""
