"""Part 3: UMAP projection of the verse embeddings."""
import numpy as np
import pandas as pd

from .config import ARTIFACTS, SEED


def umap_xy(emb: np.ndarray, tag: str) -> np.ndarray:
    f = ARTIFACTS / f"umap_{tag}.npy"
    if f.exists():
        return np.load(f)
    import umap
    xy = umap.UMAP(n_neighbors=15, min_dist=0.1, metric="cosine", random_state=SEED).fit_transform(emb)
    np.save(f, xy)
    return xy


def plot_frame(idx: pd.DataFrame, xy: np.ndarray) -> pd.DataFrame:
    return idx.assign(x=xy[:, 0], y=xy[:, 1],
                      verse=idx.raw.str.replace(r"\s+", " ", regex=True).str[:100])
