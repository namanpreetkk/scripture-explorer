"""Part 2: semantic search with multilingual-e5-base embeddings + cosine similarity."""
import numpy as np
import pandas as pd

from .config import ARTIFACTS, EMBED_MODEL, SEED


def subsample(df: pd.DataFrame, max_per: int | None) -> pd.DataFrame:
    parts = []
    for s in sorted(df.scripture.unique()):
        g = df[df.scripture == s]
        parts.append(g if not max_per else g.sample(min(len(g), max_per), random_state=SEED))
    return pd.concat(parts).reset_index(drop=True)


class SearchIndex:
    def __init__(self, idx: pd.DataFrame, emb: np.ndarray):
        self.idx, self.emb = idx, emb
        self._model = None

    @property
    def model(self):
        if self._model is None:
            import torch
            from sentence_transformers import SentenceTransformer
            device = "cuda" if torch.cuda.is_available() else "cpu"
            self._model = SentenceTransformer(EMBED_MODEL, device=device)
            self._model.max_seq_length = 128
        return self._model

    @classmethod
    def load_or_build(cls, df: pd.DataFrame, max_per: int | None, progress=None):
        tag = f"n{max_per or 'all'}"
        f_idx, f_emb = ARTIFACTS / f"idx_{tag}.pkl", ARTIFACTS / f"emb_{tag}.npy"
        if f_idx.exists() and f_emb.exists():
            return cls(pd.read_pickle(f_idx), np.load(f_emb))

        idx = subsample(df, max_per)
        self = cls(idx, np.zeros((0, 0)))
        texts = ["passage: " + t for t in idx.text]
        chunks, step = [], 1024
        for i in range(0, len(texts), step):
            chunks.append(self.model.encode(texts[i:i + step], batch_size=64,
                                            normalize_embeddings=True, show_progress_bar=False))
            if progress:
                progress(min(i + step, len(texts)) / len(texts))
        self.emb = np.vstack(chunks)
        idx.to_pickle(f_idx)
        np.save(f_emb, self.emb)
        return self

    def search(self, query: str, top_k: int = 5, scripture: str = "All") -> pd.DataFrame:
        q = self.model.encode(["query: " + query], normalize_embeddings=True)[0]
        sims = self.emb @ q
        if scripture != "All":
            sims = np.where(self.idx.scripture.values == scripture, sims, -1)
        top = np.argsort(-sims)[: int(top_k)]
        out = self.idx.iloc[top][["scripture", "ref", "raw", "translation"]].copy()
        out["raw"] = out.raw.str.replace(r"\s+", " ", regex=True)
        out["translation"] = out.translation.fillna("")
        out.insert(0, "score", sims[top].round(3))
        return out.rename(columns={"raw": "verse", "translation": "english (Ramayana only)"}).reset_index(drop=True)

    def centroid_similarity(self) -> pd.DataFrame:
        names = sorted(self.idx.scripture.unique())
        cent = np.vstack([self.emb[self.idx.scripture.values == s].mean(0) for s in names])
        cent /= np.linalg.norm(cent, axis=1, keepdims=True)
        return pd.DataFrame(cent @ cent.T, index=names, columns=names).round(3)
