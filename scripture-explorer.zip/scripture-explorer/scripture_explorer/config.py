from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data" / "DharmicData"
ARTIFACTS = ROOT / "artifacts"
ARTIFACTS.mkdir(exist_ok=True)

REPO_URL = "https://github.com/bhavykhatri/DharmicData.git"
EMBED_MODEL = "intfloat/multilingual-e5-base"
SEED = 42
