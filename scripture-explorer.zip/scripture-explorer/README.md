# 📜 Scripture Explorer (Streamlit)

Classifier + semantic search + 2D map on the [DharmicData](https://github.com/bhavykhatri/DharmicData)
corpus (Mahabharata, Valmiki Ramayana, Rigveda, Yajurveda).

| Tab | What it does | Method |
|---|---|---|
| Which scripture? | Predicts the source of a pasted verse | TF-IDF char n-grams + Logistic Regression |
| Semantic search | Finds verses by meaning | `multilingual-e5-base` + cosine similarity |
| 2D map | Map of all verses | UMAP + Plotly |
| Dataset & metrics | Corpus stats, SVM vs LogReg, confusion matrix | scikit-learn |

## Run in VS Code

1. Install **Python 3.10+**, **git**, and the VS Code *Python* extension.
2. `File → Open Folder…` and pick this folder.
3. Open the terminal (`Ctrl+``) and run:

   ```bash
   python -m venv .venv
   # Windows:  .venv\Scripts\activate        macOS/Linux:  source .venv/bin/activate
   pip install -r requirements.txt
   streamlit run app.py
   ```
4. Browser opens at http://localhost:8501. To debug, press `F5` (config in `.vscode/launch.json`).

Select the `.venv` interpreter if VS Code asks (`Ctrl+Shift+P → Python: Select Interpreter`).

## First run

- The dataset is cloned automatically into `data/DharmicData` (needs internet + git).
- The classifier trains once (~1 to few minutes) and is cached in `artifacts/`.
- Embeddings are built when you first use Search or Map (~8000 verses per scripture; slow on CPU,
  roughly 10-20+ minutes; a GPU is much faster). Everything is cached afterwards, so later runs are instant.
- To build all caches up front: `python scripts/prebuild.py`.
- Too slow? Lower "Verses to index per scripture" in the sidebar (e.g. 2000).

## Structure

```
app.py                  Streamlit UI
scripture_explorer/     data.py, classifier.py, search.py, mapping.py, config.py
scripts/prebuild.py     optional cache builder
.vscode/                interpreter + debug config
```

Delete the `artifacts/` folder to force retraining / re-embedding.
Check the DharmicData repo's LICENSE for reuse terms.
